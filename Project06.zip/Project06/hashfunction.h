#pragma once

unsigned int jsHash(const int key);